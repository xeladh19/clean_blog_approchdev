/*
../www/js/app.js
*/
function notify(message, type) {
    $.notify(
        {
            message: message,
        },
        {
            type: type,
        },
    );
}
