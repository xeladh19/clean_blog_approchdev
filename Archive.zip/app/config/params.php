<?php 
/*
../app/config/params.php
*/
//Paramètres de connexion
define('DB_HOST',       'localhost:3306');
define('DB_NAME',       'cleanBlog_2017');
define('DB_USER',       'root');
define('DB_PASSWORD',   'root');

 // Format de dates par défaut
 define('DATE_FORMAT', 'M-j-Y');

//Initialisation des zones dynamiques

$content = '';
$zoneTitre = '';
$zoneScripts = '';