<?php 
/*
../core/init.php
*/

require_once '../app/config/params.php';
require_once '../core/connection.php';
require_once '../core/functions.php';