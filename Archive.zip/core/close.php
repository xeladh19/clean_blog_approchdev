<?php 
/*
../core/close.php
*/

unset($conn);